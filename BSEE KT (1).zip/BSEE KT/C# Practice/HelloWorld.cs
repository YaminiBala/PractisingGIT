using System;
namespace HelloWorldApplication
{
class Helloworld
{
static void main(String args[])
{
Console.WriteLine("Hello");
console.ReadKeys();
}
}