﻿
using Rally.RestApi;
using Rally.RestApi.Json;
using Rally.RestApi.Response;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TFSTestsToRally
{
    public class Class1
    {

        public static void Main(string[] args)
        {
          //  Delete d1 = new Delete();
            RallyRestApi restApi = new RallyRestApi();
            restApi = new RallyRestApi(webServiceVersion: "v2.0");
            restApi.AuthenticateWithApiKey("_8NUchFImQxOTC3ztIQlye1LZD0aQkn9kHpvYqEn4I4");

            String projectRef = "/project/12725923623";
            Request testSetRequest = new Request("testfolders");
            testSetRequest.Project = projectRef;
            testSetRequest.Fetch = new List<string>();

            testSetRequest.Query = new Query("FormattedID", Query.Operator.Equals, "TF2587");
            QueryResult queryTestSetResults = restApi.Query(testSetRequest);
            String tsRef = queryTestSetResults.Results.First()._ref;
            //List<String> tsName = queryTestSetResults.Results.First().TestCases;
            //Console.WriteLine(tsName + " " + tsRef);

            DynamicJsonObject testcases = restApi.GetByReference(tsRef, "FormattedID", "TestCases");

            //IEnumerable<dynamic> testcase=JsonConvert.DeserializeObject(queryTestSetResults.Results);

            String testCasesCollectionRef = testcases["TestCases"]._ref;

            ArrayList testCasesList = new ArrayList();

            foreach (var ts in queryTestSetResults.Results)
            {
                Request tcRequest = new Request(ts["TestCases"]);

                tcRequest.Limit = 1000;

                tcRequest.Fetch = new List<string>() { "Name", "Description", "FormattedID", "Objective", "PreConditions", "PostConditions",
                          "ValidationInput", "ValidationExpectedResult", "Owner", "Risk", "Priority", "Type" };

                tcRequest.Query = new Query("TestCases", Query.Operator.Equals, "");

                QueryResult queryTestCasesResult = restApi.Query(tcRequest);

                var testName = ts["TestCases"];

                //Request tcRequest = new Request("TestCase");

                //tcRequest.Query = new Query("FormattedID", Query.Operator.Equals, "TC310521");

                //QueryResult queryTestCasesResult = restApi.Query(tcRequest);

                foreach (var tc in queryTestCasesResult.Results)
                {
                    var tName = tc["Name"];
                    var tFormattedID = tc["FormattedID"];
                    Console.WriteLine("Test Case: " + tName + " " + tFormattedID);
                    DynamicJsonObject aTC = new DynamicJsonObject();
                    aTC["_ref"] = tc["_ref"];
                    testCasesList.Add(aTC);  //add each test case in the collection to array 'testCasesList'
                }
            }

        }
    }
}


