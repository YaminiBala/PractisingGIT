﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comcast.Business.Progression.Tests.Utils
{
    public class TestSettings
    {
        

        public TestSettings()
            {
      
            }
        public string BrowserConfigurations
        {
            get
                {
                return Properties.TestSettings.Default.BrowserName;
            }
        }

        public string ApplicationURL
        {
            get
            {
                return Properties.TestSettings.Default.AppUrl;
            }
        }

        public static string Environment
        {
            get
            {
                return Properties.TestSettings.Default.Environment;
            }
        }
    }
}
