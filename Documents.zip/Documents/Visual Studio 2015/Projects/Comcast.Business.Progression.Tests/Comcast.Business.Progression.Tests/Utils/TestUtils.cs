﻿using System;
using System.Reflection;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Comcast.Business.Progression.Tests.Utils
{
    class TestUtils
    {
        public static string RelativePath
        {
            get
            {
                //#if(!DEBUG)
                //                TestSettings settings = new TestSettings();
                //                if (!string.IsNullOrEmpty(settings.RelativePath))
                //                    return settings.RelativePath;
                //#endif
                //string getFrameWorkRelativePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                //string frameWorkRelativePath = getFrameWorkRelativePath.Remove(getFrameWorkRelativePath.Length - 10);
                //return frameWorkRelativePath;
                var fullPath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
                Console.WriteLine(fullPath);
                return fullPath.Replace(@"\bin\Debug", string.Empty).Replace(@"\bin\Release", string.Empty);
            }
        }

    }
}
