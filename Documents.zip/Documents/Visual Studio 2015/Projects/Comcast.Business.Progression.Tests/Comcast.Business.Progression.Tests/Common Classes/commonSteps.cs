﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TechTalk.SpecFlow;
using Comcast.Business.Progression.Tests.Utils;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace Comcast.Business.Progression.Tests.Common_Classes
{
    [Binding]
    public class commonSteps
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks
        protected TestSettings settings;
        protected string browserName;
        protected IWebDriver browser;
        [BeforeScenario]
        public void BeforeScenario()
        {
            //TODO: implement logic that has to run before executing each scenario
            initializeSettings();
            initializeBrowsers();
        }

        private void initializeSettings()
        {
            settings = new TestSettings();
            ScenarioContext.Current.Add("settings",settings);
        }

        private void initializeBrowsers()
        {
            try
            {
                this.browserName = settings.BrowserConfigurations;
                browser = getDriver();
                browser.Manage().Window.Maximize();
                ScenarioContext.Current.Add("browser", browser);
            }
            catch(Exception)
            {
                initializeBrowsers();
            }
        }

        private IWebDriver getDriver()
            {
            IWebDriver driver = null;
            try
            {
                if (browserName.Equals("Chrome", StringComparison.CurrentCultureIgnoreCase))
                {
                    var options = new ChromeOptions();
                    options.AddArgument("start-maximized");
                    driver = new ChromeDriver(TestUtils.RelativePath + "\\ExternalLibraries\\BrowserSpecificDrivers", options);

                }
            }
            catch(Exception e)
            {

            }
            return driver;
        }

        [AfterScenario]
        public void AfterScenario()
        {
            //TODO: implement logic that has to run after executing each scenario
            closeApplication();
        }

        protected void closeApplication()
        {
            try
            {
                //WebDriverFactory.TerminateWebDriver(browser);
                browser.Close();
                browser.Quit();
                browser.Dispose();
                //Context.SetWebDriver(null);
            }
            catch (Exception e)
            {
               
                browser.Dispose();
            }
            finally
            {
                browser.Dispose();
                GC.SuppressFinalize(browser);

            }


        }
    }
}
