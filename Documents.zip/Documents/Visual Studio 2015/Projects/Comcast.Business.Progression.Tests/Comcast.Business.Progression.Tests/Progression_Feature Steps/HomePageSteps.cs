﻿using System;
using TechTalk.SpecFlow;

namespace Comcast.Business.Progression.Tests.Progression_Feature_Steps
{
    [Binding]
    public class HomePageSteps
    {

        public HomePageSteps() :
            base()
        {
            if (!ScenarioContext.Current.ContainsKey("homePage"))
                ScenarioContext.Current.Add("homePage", homePage);
            homePage = ScenarioContext.Current.Get<HomePage>("homePage");

        }
        [Given(@"Iam on the Home Page")]
        public void GivenIamOnTheHomePage()
        {
            if (!ScenarioContext.Current.ContainsKey("homePage"))
                ScenarioContext.Current.Add("homePage", homePage);
            homePage = ScenarioContext.Current.Get<HomePage>("homePage");
        }
        
        [When(@"I directly go to the Help-and-Support page")]
        public void WhenIDirectlyGoToTheHelp_And_SupportPage()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"I verify Search Box is displayed")]
        public void ThenIVerifySearchBoxIsDisplayed()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"I verify Search Suggestions Dropdown")]
        public void ThenIVerifySearchSuggestionsDropdown()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"In the navigation header I search for ethernet and hit search button")]
        public void ThenInTheNavigationHeaderISearchForEthernetAndHitSearchButton()
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"the ethernet search results page displayed")]
        public void ThenTheEthernetSearchResultsPageDisplayed()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
